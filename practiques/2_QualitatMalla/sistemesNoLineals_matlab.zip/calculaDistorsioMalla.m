function distorsioMalla = calculaDistorsioMalla(X,T)
%
% distorsioMalla = calculaDistorsioMalla(X,T)

A = [
    1  -sqrt(3)/3
    0   2*sqrt(3)/3
    ];

% Completar el codi per calcular la distorsi? de la malla amb nodes X i
% connectivitats T
% ...
% ...
% ...

